@echo off
cd /d "%~dp0"
if not exist "PUMPKO-CONFIG.exe" (
 echo ERROR: Native Windows configuration executable is missing.
 echo Use the rebuilt Win32 package, not the older PowerShell release.
 pause
 exit /b 1
)
"PUMPKO-CONFIG.exe"
if errorlevel 1 (
 echo Setup did not complete. No PowerShell is required.
 pause
 exit /b 1
)
pause
