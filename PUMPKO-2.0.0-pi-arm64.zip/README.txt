PUMPKO v2.0.0 - Revenge of the Pumpkins
=====================================

This ZIP contains three files: the installer, this guide, and FILE_ID.DIZ.

Windows x86 / x64:
  Double-click PUMPKO-SETUP.exe. Choose the installation directory.
  New installs ask for a BBS name (up to 20 display characters), domain,
  and InterBBS score sharing. No Python or PowerShell required.
  Windows 7 SP1 needs working TLS 1.2 and an up-to-date certificate store.

Linux x64 / Raspberry Pi ARM64:
  Run: bash INSTALL-LINUX.sh
  Requires Bash, tar, and standard shell tools. InterBBS also requires
  curl with HTTPS support and a working system CA certificate store.
  No Python required for installation or score synchronization.

Official Score Hub: https://scores.a-net.online
New participating BBSes enroll automatically. Credentials remain private.
Choose local-only play if you do not want score sharing.

UPGRADE: stop game sessions and sync workers; run the new installer and
select the existing directory. Existing game settings, enrolled identity,
credentials, scores and player profiles are preserved. Changed program
files and documentation get .previous backups. Identical files do not.
Existing settings take precedence over the Windows form on upgrades.
A previous Windows SQLite sync checkpoint is migrated without resetting
its acknowledged byte offset. The original database is retained.

After installing, see docs/INSTALL.txt to add the door to your BBS menu.
Set the BBS door's working directory to the installed PUMPKO directory.
Never publish hub/sync.json or configuration backups: they contain secrets.

Build and runtime verification details: docs/RELEASE-VALIDATION.txt.

Optional shared live chat: answer Y during setup to join the same lobby as
ANetARCADE. Answer N to hide chat. Use PUMPKO --chat-config to change later.
See installed docs/SHARED-CHAT.txt. Reuse existing Hub credentials.
